### PYTHON REVERSI - Based on the classic boardgame "Reversi"
### Last Revision: 2008-12-07
### ACP


##Import necessary modules etc.
import pygame
import gridcells
from pygame.locals import *
from sys import exit

pygame.init()

## Setup window and background
windowres = (640, 384)
screen = pygame.display.set_mode(windowres)
pygame.display.set_caption("Reversi; An Adventure in Grids - ACP")

background = pygame.Surface(screen.get_size())
background = background.convert()
background.fill((125, 125, 60))



## Declare initial variables
mousex = mousey = 0
gridplacex = gridplacey = 0

## Create grid
tilesize = 48
dimensions = (8, 8)

grid = gridcells.grid(screen, tilesize, dimensions)
gridgroup = pygame.sprite.Group(grid)

player = gridcells.playermove(1, tilesize, dimensions)

## Create text

p1score = gridcells.scoredisplay(1, 100)
p2score = gridcells.scoredisplay(2, 125)
scoregroup = pygame.sprite.Group(p1score, p2score)

resettext = gridcells.text(500, 360, 30, (180, 180, 0), "(r)eset")
quittext = gridcells.text(580, 360, 30, (180, 180, 0), "(q)uit")
titletext = gridcells.text(420, 30, 60, (200, 200, 200), "REVERSI")

message = gridcells.message(400, 200, 1)
message2 = gridcells.message(400, 180, 2)
textgroup = pygame.sprite.Group(resettext, quittext, message, message2, titletext)


## Main runtime loop
clock = pygame.time.Clock()
dim = grid.dimensions
til = grid.tilesize

while True:
	## Quick framerate not needed - low for efficiency.
	clock.tick(15)

	# Quit if x clicked.
	for event in pygame.event.get():
		if event.type == QUIT:
			exit()
		elif event.type == pygame.MOUSEBUTTONDOWN:
			mouseclick = event.pos
			player.domove(mouseclick)	

	# Act on keypresses.
	keypress = pygame.key.get_pressed()
	if keypress[K_q]:
		exit()
	elif keypress[K_r]:
		player = gridcells.playermove(1, tilesize, dimensions)
		grid = gridcells.grid(screen, tilesize, dimensions)
		scoregroup = pygame.sprite.Group(p1score, p2score)
		gridcells.messagetext = {1:"Player 1 to move.", 2: "Welcome to Reversi!"}
		for key in gridcells.dictscores:
			gridcells.dictscores[key] = 2

	# Build display.
	screen.blit(background, (0, 0))
	gridgroup.update(screen)
	scoregroup.update()
	scoregroup.draw(screen)
	textgroup.update()
	textgroup.draw(screen)

	pygame.display.flip()
