README.TXT
Python Reversi
ACP


CONTENTS:
1) Setup
2) How to Play
3) Input



1) Setup:

Python Reversi requires Python and Pygame. These can be downloaded from:

http://www.python.org/download/
http://www.pygame.org/download.shtml

Once these are installed, the game can be run by placing the main.py and gridcells.py files in the same folder and:

On UNIX-based systems:
Navigate to the containing folder in terminal and enter "python main.py"

On Windows:
Double-click on the main.py script.



2) How to Play:

Python Reversi, or Othello, is a two-player game played on a grid, in which the aim is to own more board squares than your opponent when the game reaches such a state that no more moves can be played.

Players take it in turns to place tiles with the mouse. A move is only valid if placing a tile causes some of your opponent's tiles to be surrounded in at least one direction (diagonals included). Placing a tile will cause all of your opponent's tiles which are between this tile and another of yours to flip and become yours.

If a player cannot place a tile due to a lack of valid options, the move will be skipped automatically. If neither player can move, the game is over and each player's tiles are totalled, determining a winner.



3) Input:
Mouse Button:- Place tile
R - Reset Game
Q - Quit Game

